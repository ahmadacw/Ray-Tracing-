

public class Settings {
Vector bg;
float sh_rays;
float rec_max;
float SS;
public Settings(Vector bg, float f, float g, float h) {
	super();
	this.bg = bg;
	this.sh_rays = f;
	this.rec_max = g;
	SS = h;
}

}
